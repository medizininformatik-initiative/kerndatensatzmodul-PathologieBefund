# EXA MII Patho Canada Balsam - MII IG Modul Patho v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **EXA MII Patho Canada Balsam**

## Beispiel Substance: EXA MII Patho Canada Balsam

-------

**German**

-------

Profile: [MII PR Biobank Substance Additiv](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.biobank@2027.0.0-ballot.rc2&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance)

**code**: Canada balsam (substance)



## Resource Content

```json
{
  "resourceType" : "Substance",
  "id" : "mii-exa-patho-canadabalsam",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance"]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "412582000",
      "display" : "Canada balsam (substance)"
    }]
  }
}

```
