# Szenarien - MII IG Modul Patho v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Anwendungsfälle und Informationsmodell**](anwendungsfaelle.md)
* **Szenarien**

## Szenarien

Für einen generischen Pathologiebefundbericht sind verschiedene Szenarien möglich, betreffend:

* **Berichtsstatus**: Pathologiebefundberichte können vorläufig oder endgültig sein. In beiden Fällen bedürfen sie der expliziten Befundfreigabe durch den verantwortlichen Pathologen. Die betreffenden Aspekte des Dokumentenworkflow, die in diesem Implementation Guide nicht geregelt werden, sind im Abschnitt ["Hierarchie und Workflow-Aspekte"](hierarchie.md) beschrieben. Das betrifft insbesondere den Umgang mit Nach-, Zusatz- und Korrekturberichten."
* **Nach-, Zusatz- und Korrekturberichte**: Diese ersetzen prinzipiell die vorhandene aktuelle Version eines Befundberichtes. Dafür kann die Möglichkeit eines Informationsupdates genutzt werden, um auf den Teil des Berichtes hinzuweisen, den das Update betrifft, und um die klinische Relevanz des Updates zu klassifizieren
* **Komplexität des Befundberichtes**: Pathologiebefundberichte können zu Einsendungen einer einzelnen Probe (Einsendung) mit einer einzigen klinischen Fragestellung (z.B. Hautexzisat, Fragestellung: Art des Hauttumors) oder zu einer Probe (Einsendung), bestehend aus mehreren Teilen (Parts, die gemäß Definition wiederum Proben sind), mit verschiedenen Untersuchungsaufträgen und Fragestellungen erstellt werden, z.B.:

Für komplexe Befundberichte müssen die kodierten Informationen durch den Mechanismus eines "Organizers" entsprechend organisiert werden können. Dieser Organizer-Mechanismus ist in FHIR nicht vorgesehen, weshalb in diesem Modul andere adäquate Lösungen (z.B. Grouper-Observations) genutzt worden sind.

Um strukturierte kodierte und semantisch annotierte Informationen in einen Pathologiebefundbericht aufnehmen zu können, oder um diesen ganz oder teilweise durch derartige kodierte Datenelemente aufzubauen, benötigen Pathologiesysteme entsprechende Erfassungswerkzeuge. Für das Modul bieten sich dafür die im [FHIR IG Structured Data Capture](http://hl7.org/fhir/uv/sdc/) beschriebenen Funktionen zur Datenerfassung und Extrahierung aus FHIR Questionnaires an, damit ist eine direkte Übernahme der erfassten Daten in den strukturierten Befundbericht möglich.

### Exemplarischer Anwendungsfall: Pathologiebefundbericht für Prostatastanzbiopsien gemäß ICCR-Vorgaben

Patient A., B., m., 61 Jahre alt, sucht seinen Urologen Dr. C., D. in der Ambulanz der Urologischen Klinik auf, zu der er von seinem Hausarzt wegen erhöhtem PSA-Wert überwiesen wurde. Dr. C. stellt nach Anamnese und rektaler digitaler Untersuchung die Indikation zur Prostatastanzbiopsie, die er nach Lokalanästhesie als ultraschallgestützte Sextantenbiopsie durch führt.

In Vorbereitung darauf ruft er in seinem PVS/KIS das um organspezifische Informationen erweiterte KBV-Muster 10 auf (das auch als Abrufformular vom Patho-LIS der Pathologie abgerufen werden könnte), in das die Patienten-/Versichertendaten (subject, insurance), die Arzt- und Einrichtungsdaten (requester, performerType, performer) aus dem PVS/KIS übernommen werden und in das in strukturierter Form der Einsendungsgrund (reasonCode), die Anamnese und die aktuellen Probleme des Patienten sowie Ergebnisse von Laboruntersuchungen (PSA!) (jeweils supportingInfo), die Ziel-Lokalisationen der Stanzbiopsie innerhalb der Prostata, die je Lokalisation gewonnene Anzahl von Stanzzylindern und deren Länge (specimen. …) eingetragen werden. Dr. C agiert als Order Placer.

Nach den zwölf Stanzlokalisationen getrennt gibt er die einzelnen gewonnen Stanzzylinder in zwölf Probenröhrchen, die mit dem Patientennamen, dessen Geburtsdatum, der Auftragsnummer und der Probenbezeichnung beschriftet werden. Die dafür erforderlichen Aufkleber werden vom PVS/KIS bereitgestellt.

Aus diesen Informationen entsteht im PVS/KIS ein ServiceRequest mit einem Placer Identifier mit dazugehörigen Specimen-Informationen einschließlich ID´s und Probenbezeichnungen (Proben-Identifier). Diese FHIR Instanzen werden an das mit der Untersuchung zu beauftragende Pathologie-Institut gesendet, die Probengefäße zusammen mit einem PDF-Ausdruck des Muster 10 übersandt.

Im Probeneingang des Pathologie-Instituts (Order filler) werden die Probengefäße und der PDF-Ausdruck des Muster 10 (Einsendungsschein) mit den inzwischen im Patho-LIS vorhandenen FHIR Instanzen zur Einsendung abgeglichen, die Probengefäße auf Vollständigkeit und die Proben auf Unversehrtheit überprüft und der klinische Auftrag (Placer order) in einen Fall des Pathologie-Instituts überführt. Dazu wird für diesen Auftrag (oder für weitere zusammengehörige Aufträge) ein Filler order mit der Fall-Nummer (Accession identifier) angelegt und für die dazugehörigen Proben die Probenbezeichnungen des Klinikers übernommen oder neue Bezeichnungen vergeben.

Das Patho-LIS bestätigt den Eingang des klinischen Untersuchungsauftrags und der Proben und teilt dem PVS/KIS die zugewiesene Fall-Nummer sowie die Annahme des Untersuchungsauftrages (oder dessen Nichtdurchführbarkeit wegen u.a. Problemen mit den Proben) mit. Dafür existiert bisher kein FHIR-Mechanismus im Rahmen des MII-Pathologiebefundes. HL7 Order&Observations arbeitet an einer Lösung (FHIR COW … Clinical Order Workflow). Üblicherweise werden dazu bisher HL7 V2.x Nachrichten verwendet.

Im sog. Zuschnitt des Pathologie-Instituts werden die Proben makroskopisch beschrieben. Diese Beschreibung wird auf einem FHIR Questionnaire für jede einzelne Stanze dokumentiert. Die im Patho-LIS aus dem ServiceRequest vorhandenen Informationen sind in diesem Questionnaire bereits vorausgefüllt und werden entweder übernommen oder verändert oder ergänzt.

Nach der Gewebspäparation des Probenmaterials (Einbetten, Schneiden, Färben, Eindecken) werden die gefärbten Schnittpräparate (u.U. digitalisiert) fallweise sortiert und dem zuständigen Pathologen Dr. E.,F. zur mikroskopischen Beurteilung zugewiesen. Das Patho-LIS kontrolliert die Vollständigkeit der gefärbten Schnittpräparate gemäß Probeneingang und makroskopischer Beschreibung und benachrichtigt den zuständigen Pathologen Dr. E über das Vorliegen eines befundungsbereiten Falls.

Nach Aufruf eines weiteren Questionnaires werden die mikroskopischen Befunde jeder einzelnen Stanzbiopsie strukturiert erfasst und in einem dritten Questionnaire die fallbezogene Zusammenfassung ebenfalls strukturiert vorgenommen.

Die QuestionnaireResponses werden vom FHIR-Server des Pathologie-Insitutes automatisch in einen FHIR-PathoReport überführt, der in eine FHIR-Composition eingebettet wird, welche als FHIR-Bundle vom zuständigen Pathologen Dr. E nach Kontrolle des fertigen (human readable) Befundberichts signiert werden kann und danach als PDF-Dokument zusammen mit den genannten eingebetteten FHIR-Instanzen and das PVS/KIS des Einsenders übersandt wird (xds-Verfahren), oder per Mitteilung dem Einsender zum Abruf aus dem FHIR-Server angeboten wird.

Das PVS/LIS liest in seiner Funktion als Order result tracker die übersandten/abgerufenen FHIR-Instanzen aus dem Pathologie-Institut ein und benachrichtigt den Urologen Dr. C über das Vorliegen eines angeforderten Pathologiebefundberichts für seinen Patienten, Herrn A., B.

Auf Wunsch von Herrn A. überträgt Dr. C. nach der Erläuterung des Befundes diesen in die ePA von Herrn A.

Für eine vollständige, exemplarische Umsetzung dieses Anwendungsfalls als FHIR Implementation Guide siehe den [Prostate Cancer Spec IG](https://bih-cei.github.io/ProstateCancerSpec/index.html).

