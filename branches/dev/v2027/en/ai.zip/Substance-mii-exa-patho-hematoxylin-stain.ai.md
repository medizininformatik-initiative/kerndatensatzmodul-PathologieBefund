# EXA MII Patho Hematoxylin-stain - MII IG Modul Patho v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EXA MII Patho Hematoxylin-stain**

## Example Substance: EXA MII Patho Hematoxylin-stain

-------

**English**

-------

Profile: [MII PR Biobank Substance Additiv](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.biobank@2027.0.0-ballot.rc2&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance)

**code**: Hematoxylin stain



## Resource Content

```json
{
  "resourceType" : "Substance",
  "id" : "mii-exa-patho-hematoxylin-stain",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance"]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "12710003",
      "display" : "Hematoxylin stain"
    }]
  }
}

```
