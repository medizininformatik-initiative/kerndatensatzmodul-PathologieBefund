# mii-exa-patho-practitioner-1234 - MII IG Modul Patho v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-patho-practitioner-1234**

## Example Practitioner: mii-exa-patho-practitioner-1234

-------

**English**

-------

**name**: Lena Labor 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "mii-exa-patho-practitioner-1234",
  "name" : [{
    "family" : "Labor",
    "given" : ["Lena"]
  }]
}

```
