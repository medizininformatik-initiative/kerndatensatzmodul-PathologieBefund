# MII VS Patho Container Type [SNOMED CT] - MII IG Modul Patho v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS Patho Container Type [SNOMED CT]**

## ValueSet: MII VS Patho Container Type [SNOMED CT] 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/ValueSet/mii-vs-patho-container-type-snomed-ct | *Version*:2027.0.0-ballot |
| Active Stand: 2026-11-27 | *Maschinenlesbarer Name*:MII_VS_Patho_Container_Type_SNOMED_CT |

 
ValueSet for container type based on IHE PaLM's ContainerEntityClassType ValueSet 

 **References** 

* [MII PR Patho Specimen](StructureDefinition-mii-pr-patho-specimen.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-patho-container-type-snomed-ct",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/ValueSet/mii-vs-patho-container-type-snomed-ct",
  "version" : "2027.0.0-ballot",
  "name" : "MII_VS_Patho_Container_Type_SNOMED_CT",
  "_name" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "MII_VS_Patho_Container_Type_SNOMED_CT"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "title" : "MII VS Patho Container Type [SNOMED CT]",
  "_title" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "MII VS Patho Container Type [SNOMED CT]"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "status" : "active",
  "date" : "2026-11-27T15:16:10+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik-Initiative"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    },
    {
      "system" : "email",
      "value" : "info@medizininformatik-initiative.de"
    }]
  }],
  "description" : "ValueSet for container type based on IHE PaLM's ContainerEntityClassType ValueSet",
  "_description" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "ValueSet for container type based on IHE PaLM's ContainerEntityClassType ValueSet"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "434746001",
        "display" : "Specimen vial"
      },
      {
        "code" : "434464009",
        "display" : "Tissue cassette"
      },
      {
        "code" : "434708008",
        "display" : "Tissue cassette for microarray"
      },
      {
        "code" : "433466003",
        "display" : "Microscope slide"
      },
      {
        "code" : "433453003",
        "display" : "Specimen container component"
      },
      {
        "code" : "434533009",
        "display" : "Electron microscopy grid"
      },
      {
        "code" : "434822004",
        "display" : "Specimen well"
      },
      {
        "code" : "433472003",
        "display" : "Microscope slide coverslip"
      },
      {
        "code" : "434473001",
        "display" : "Specimen container lid"
      },
      {
        "code" : "706053007",
        "display" : "General specimen container"
      }]
    }]
  }
}

```
