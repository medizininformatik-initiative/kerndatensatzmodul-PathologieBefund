# Core Data Set Module Pathology Report - MII IG Modul Patho v2027.0.0

* [**Table of Contents**](toc.md)
* **Core Data Set Module Pathology Report**

## Core Data Set Module Pathology Report

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/ImplementationGuide/mii-ig-modul-patho | *Version*:2027.0.0 |
| Active as of 2026-09-01 | *Computable Name*:MII_IG_Modul_Patho |

### Introduction

This specification describes the FHIR representation of the core data set module 'Pathology Report' of the Medical Informatics Initiative (MII). The use cases of the module as well as the associated FHIR profiles and terminology resources are described below in their binding form.

| | |
| :--- | :--- |
| Date | 2026-09-01 |
| Version | 2027.0.0 |
| Status | Active |
| Realm | DE |

#### Entry points

* [Module description](beschreibung.md) — what the pathology report covers and how it is structured
* [Use cases and information model](anwendungsfaelle.md) — scenarios, data sets, UML and hierarchy
* [Artifacts](artifacts.md) — profiles, terminologies and examples
* [Downloads](downloads.md) — FHIR package and definitions

### Contact and participation

This guide was created as part of the Medical Informatics Initiative and is subject, by governance process, to the voting procedure of the Interoperability Forum and of the Technical Committees of HL7 Deutschland e. V.

Questions about this publication can be asked at any time at [chat.fhir.org](https://chat.fhir.org) in the stream 'german/mi-initiative'.

Comments and criticism are always welcome in the form of 'issues' in the [GitHub repository](https://github.com/medizininformatik-initiative/kerndatensatzmodul-PathologieBefund) or in the [Simplifier project](https://simplifier.net/medizininformatikinitiative-modulpathologie).

#### Contacts

* Thimo Hölter (Berlin Institute of Health at Charité)
* Sylvia Thun (Berlin Institute of Health at Charité)

#### Authors (in alphabetical order)

* Alexander Bartschke (Berlin Institute of Health at Charité)
* Karl-Friedrich Becker (TU München)
* Martin Boeker (TU München)
* Melanie Börries (Uniklinikum Freiburg)
* Thomas Debertshäuser (Berlin Institute of Health at Charité)
* Andrea Essenwanger (Berlin Institute of Health at Charité)
* Gunter Haroske (Berufsverband Deutscher Pathologinnen und Pathologen)
* Thimo Hölter (Berlin Institute of Health at Charité)
* Marlon Kazmierczak (Berufsverband Deutscher Pathologinnen und Pathologen)
* Thomas Rüdiger (Klinikum Karlsruhe)
* Julian Saß (Berlin Institute of Health at Charité)
* Sylvia Thun (Berlin Institute of Health at Charité)

### Copyright and licence

Copyright © 2022+: TMF e. V., Charlottenstraße 42, 10117 Berlin

The content of this specification is public. Reuse and publication rights are not restricted. For the usage rights of the underlying FHIR technology, see the FHIR base specification. Some of the code systems used are published and maintained by other organizations; the copyright of the respective publishers listed there applies.

### Disclaimer

The content of this document is public. Please note that parts of this document are based on FHIR version R4, for which the copyright of HL7 International applies.

Although this publication has been prepared with the greatest care, the authors cannot accept any liability for direct or indirect damage that could arise from the content of this specification.

