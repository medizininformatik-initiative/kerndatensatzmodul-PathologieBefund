# Kontext und Bezüge - MII IG Modul Patho v2027.0.0-ballot.rc

* [**Table of Contents**](toc.md)
* **Kontext und Bezüge**

## Kontext und Bezüge

Das Modul **Pathologie-Befund** bildet Pathologiebefunde ab, die typischerweise in einer Pathologieeinrichtung eines Klinikums erhoben werden. Diese Befunde spielen in einigen Use Cases der MII eine zentrale Rolle:

* Pathologiebefundberichte aus Routineuntersuchungen sind essentiell für Diagnosefindung und Therapieüberwachung bei den meisten Erkrankungen
* Pathologiebefundberichte sind ein wichtiger Bestandteil vieler klinischer Studien

### Bezüge innerhalb der MII

Ein Pathologiebefundbericht ist dabei immer der [Person](https://medizininformatik-initiative.github.io/kerndatensatz-basis/de/StructureDefinition-mii-pr-person-patient.html) zugeordnet, von welcher die **Proben** entnommen wurden und auf einen [Versorgungsstellenkontakt](https://medizininformatik-initiative.github.io/kerndatensatz-basis/de/StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.html) bezogen. Bei dem **Versorgungsstellenkontakt** handelt es sich um einen pathologieeinrichtungspezifischen **(Abteilungs)kontakt**, die sogenannte Einsendung, der alle Untersuchungsaufträge zu Proben einer Person, die in einem zeitlichen und fachlichen Zusammenhang entnommen wurden, zusammenfasst. Dieser **Versorgungsstellenkontakt** muss nicht identisch mit dem Untersuchungsauftrag sein. Wenn eine Probe eines Falles in einer Biobank für weitere Untersuchungen verwahrt wird, kann diese Probe mit den Profilen im Modul [Bioproben](https://simplifier.net/medizininformatikinitiative-modulbiobank) abgebildet werden. Die Ergebnisse aus einem Pathologiebefundbericht können als einzelne Elemente in verschiedenen anderen Modulen, z.B. zur Tumordokumentation, wieder eingebunden sein.

Andererseits können Befundberichte aus anderen Disziplinen (z.B. aus den Modulen [Molekulargenetischer Befundbericht](https://simplifier.net/medizininformatikinitiative-modulomics) oder [Labor](https://simplifier.net/medizininformatikinitiative-modullabor) ganz oder auszugsweise in Pathologiebefundberichte aufgenommen und im Sinne einer synoptischen Bewertung interpretiert werden.

Weiterhin kann eine Beziehung zum Modul [Diagnose](https://medizininformatik-initiative.github.io/kerndatensatz-basis/de/StructureDefinition-mii-pr-diagnose-condition.html) bestehen. Eine Diagnose kann von einem Untersuchungsauftrag (z.B. als Teil der klinischen Angaben/Anamnese) referenziert werden. Diese kann aber auch selber auf einen Befund referenzieren, wenn dieser als Evidenz z.B. zum Staging der gestellten Diagnose dienen soll.

### Bezüge außerhalb der MII

Da es sich bei Pathologie Systeme um sogenannte Subsysteme im Krankenhaus handeln kann, ist eine Kompatibilität zu [ISiK](https://simplifier.net/packages/de.gematik.isik-basismodul/4.0.1) essenziell für die Umsetzung der Pathologie Profile der Medizininformatik Initiative. So wird für die Bündelung der Pathologie Ressourceninstanzen eine Composition/Bundle verwendet, welche vom ISiK Profil [ISiKBerichtSubsysteme](https://simplifier.net/isik-stufe-5/isikberichtsubsysteme) erbt.

