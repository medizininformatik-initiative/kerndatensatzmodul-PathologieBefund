# EXA MII Patho Eosin Y - MII IG Modul Patho v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **EXA MII Patho Eosin Y**

## Beispiel Substance: EXA MII Patho Eosin Y

-------

**German**

-------

Profile: [MII PR Biobank Substance Additiv](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.biobank@2026.0.1&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance)

**code**: Eosin Y (substance)



## Resource Content

```json
{
  "resourceType" : "Substance",
  "id" : "mii-exa-patho-eosin-y",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance"]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "763042003",
      "display" : "Eosin Y (substance)"
    }]
  }
}

```
