# EXA MII Patho Neutral Buffered Formalin - MII IG Modul Patho v2027.0.0

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **EXA MII Patho Neutral Buffered Formalin**

## Beispiel Substance: EXA MII Patho Neutral Buffered Formalin

-------

**German**

-------

Profile: [MII PR Biobank Substance Additiv](file:///home/runner/work/kerndatensatzmodul-biobank/kerndatensatzmodul-biobank/output/StructureDefinition-mii-pr-biobank-substance-additiv.html)

**code**: Neutral buffered formalin



## Resource Content

```json
{
  "resourceType" : "Substance",
  "id" : "mii-exa-patho-neutral-buffered-formalin",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance"]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "434162003",
      "display" : "Neutral buffered formalin"
    }]
  }
}

```
