# UML - MII IG Modul Patho v2027.0.0-ballot.rc

* [**Table of Contents**](toc.md)
* [**Anwendungsfälle und Informationsmodell**](anwendungsfaelle.md)
* **UML**

## UML

Als abstraktere Version eines Informationsmodells und zur besseren Verdeutlichung von Beziehungen der fachlichen Konzepte untereinander wurde ein UML-Klassendiagramm erstellt, das aus dem HL7-CDA-RMIM abgeleitet wurde. In ART-DECOR als Gruppen abgebildete Konzepte werden als eigene Klassen modelliert, die hier Assoziationsbeziehungen zueinander haben. Diese Konzepte bilden dabei nur die inhaltliche/klinische Modellierung ab, somit entsprechen die einzelnen Klassen nicht immer auch einem FHIR Profil. Ein Pathologiebefundbericht ist hierbei assoziiert mit einem Patienten oder einer Patientin, einem Versorgungsfall, einer Gesundheitseinrichtung, einem Untersuchungsauftrag, untersuchtem Probenmaterial und den jeweiligen Befunden und diagnostischen Schlussfolgerungen einer pathologisch-anatomischen Untersuchung. Solche Befunde und Schlussfolgerungen haben eine textliche Repräsentation und können spezifische semantische Annotationen zu Befunddetails enthalten. Klassen, die auf Konzepten aus anderen Kerndatensatzmodulen beruhen, sind farblich von den Pathologiebefundbericht-Klasssen abgehoben.

![](patho_uml_v2026.png)

