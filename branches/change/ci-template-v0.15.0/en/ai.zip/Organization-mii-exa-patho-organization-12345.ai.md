# mii-exa-patho-organization-12345 - MII IG Modul Patho v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-patho-organization-12345**

## Example Organization: mii-exa-patho-organization-12345

-------

**English**

-------

Institute of Pathology

-------



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "mii-exa-patho-organization-12345",
  "name" : "Institut für Pathologie",
  "_name" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "Institute of Pathology"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  }
}

```
