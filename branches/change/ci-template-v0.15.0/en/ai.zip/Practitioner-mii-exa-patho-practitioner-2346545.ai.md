# mii-exa-patho-practitioner-2346545 - MII IG Modul Patho v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-patho-practitioner-2346545**

## Example Practitioner: mii-exa-patho-practitioner-2346545

-------

**English**

-------

Sabine Schnitt

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "mii-exa-patho-practitioner-2346545",
  "name" : [{
    "family" : "Schnitt",
    "given" : ["Sabine"]
  }]
}

```
