# mii-exa-patho-practitioner-34456 - MII IG Modul Patho v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-patho-practitioner-34456**

## Example Practitioner: mii-exa-patho-practitioner-34456

-------

**English**

-------

Ulrich Urban

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "mii-exa-patho-practitioner-34456",
  "name" : [{
    "family" : "Urban",
    "given" : ["Ulrich"]
  }]
}

```
