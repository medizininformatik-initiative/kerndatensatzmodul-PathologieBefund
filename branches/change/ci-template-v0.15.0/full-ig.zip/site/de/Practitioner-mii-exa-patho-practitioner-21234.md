# mii-exa-patho-practitioner-21234 - MII IG Modul Patho v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-exa-patho-practitioner-21234**

## Beispiel Practitioner: mii-exa-patho-practitioner-21234

-------

**German**

-------

Martin Makro

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "mii-exa-patho-practitioner-21234",
  "name" : [{
    "family" : "Makro",
    "given" : ["Martin"]
  }]
}

```
